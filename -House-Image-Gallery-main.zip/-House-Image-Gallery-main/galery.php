<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title> Galeria de Imagens </title>
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
<style type="text/css">
  [class*="col"]{
    border: 2px solid darkred;
    height: 33.3vh;
    font-style: italic;
    font-weight: bold;
    font-size: 20px;
    font-variant:small-caps;
    font-family:Arial, Helvetica, sans-serif;
    color: darkred;
  }
  #imgI{
    background-image:url("quarto/quarto.jpg1");
    background-repeat: no-repeat;
  }
  #imgII{
    background-image:url("quarto/quarto.jpg2");
    background-repeat: no-repeat;
  }
  #imgIII{
    background-image:url("quarto/quarto.jpg3");
    background-repeat: no-repeat;
  }
  #imgIV{
    background-image:url("sala/sala.jpg1");
    background-repeat: no-repeat;
  }
  #imgV{
    background-image:url("sala/sala.jpg2");
    background-repeat: no-repeat;
  }
  #imgVI{
    background-image:url("sala/sala.jpg3");
    background-repeat: no-repeat;
  }
  #imgVII{
    background-image:url("cozinha/cozinha.jpg1");
    background-repeat: no-repeat;
  }
  #imgVIII{
    background-image:url("cozinha/cozinha.jpg2");
    background-repeat: no-repeat;
  }
  #imgIX{
    background-image:url("cozinha/cozinha.jpg3");
    background-repeat: no-repeat;
  }
  #imgX{
    background-image:url("banheiro/banheiro.jpg1");
    background-repeat: no-repeat;
  }
  #imgXI{
    background-image:url("banheiro/banheiro.jpg2");
    background-repeat: no-repeat;
  }
  #imgXII{
    background-image:url("banheiro/banheiro.jpg3");
    background-repeat: no-repeat;
  }
  #imgXIII{
    background-image:url("garagem/garagem.jpg1");
    background-repeat: no-repeat;
  }
  #imgXIV{
    background-image:url("garagem/garagem.jpg2");
    background-repeat: no-repeat;
  }
  #imgXV{
    background-image:url("garagem/garagem.jpg3");
    background-repeat: no-repeat;
  }
  

  }*/
</style>
</head>
<body>
  <div class="container">
  <div class="row">
  <div class="col" id="imgI">
  </div>
  <div class="col" id="imgII">
  </div>
  <div class="col" id="imgIII">
  </div>
  <div class="container">
  <div class="row">
  <div class="col" id="imgIV">
  </div>
  <div class="col" id="imgV">
  </div>
  <div class="col" id="imgVI">
  </div> 
  <div class="container">
  <div class="row">
  <div class="col" id="imgVII">
  </div>
  <div class="col" id="imgVIII">
  </div>
  <div class="col" id="imgIX">
  </div>
  <div class="container">
  <div class="row">
  <div class="col" id="imgX">
  </div>
  <div class="col" id="imgXI">
  </div>
  <div class="col" id="imgXII">
  </div> 
  <div class="container">
  <div class="row">
  <div class="col" id="imgXIII">
  </div>
  <div class="col" id="imgXIV">
  </div>
  <div class="col" id="imgXV">
  </div>
 </div>
  <script src="bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<!-- DUPLA: WILLY E ISMAEL -->